package th.ac.su.chanunchida.simpleloancalculator.data

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.activity_main.view.tvTitle
import kotlinx.android.synthetic.main.list_item_simple.view.*
import th.ac.su.chanunchida.simpleloancalculator.R

class SimpleAdapter(private val context: Context,
                    private val dataSource:ArrayList<Simple>) : BaseAdapter(){


    private val inflater:LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater



    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {


        val rowView = inflater.inflate(R.layout.list_item_simple,null)

        rowView.tvTitle.text = dataSource[position].promo_name
        rowView.tvSubtitle.text = dataSource[position].promo_code.toString()
        rowView.tvDetail.text = dataSource[position].promo_description


        rowView.imgThumbnail.setImageResource(R.drawable.monster01_tn)

        val res = context.resources
        val drawableId:Int =
            res.getIdentifier(dataSource[position].imageFile,"drawable",context.packageName)

        rowView.imgThumbnail.setImageResource(drawableId)


        return rowView

    fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        TODO("Not yet implemented")
    }

    fun getItem(position: Int): Any {
        return dataSource[position]
    }

    fun getItemId(position: Int): Long {
        return position.toLong()
    }

    fun getCount(): Int {
        return  dataSource.size
    }

}