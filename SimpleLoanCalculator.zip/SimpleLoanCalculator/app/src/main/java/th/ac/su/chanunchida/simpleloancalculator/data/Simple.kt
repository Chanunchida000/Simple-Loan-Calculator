package th.ac.su.chanunchida.simpleloancalculator.data

data class Simple(
    val promo_name: String,
    val promo_description: String,
    val promo_code: Int,
    val imageFile: String
)