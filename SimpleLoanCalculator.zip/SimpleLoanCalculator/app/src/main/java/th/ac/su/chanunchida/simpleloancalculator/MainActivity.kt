package th.ac.su.chanunchida.simpleloancalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import th.ac.su.chanunchida.simpleloancalculator.Utils.getJsonDataFromAsset
import th.ac.su.chanunchida.simpleloancalculator.data.Simple
import th.ac.su.chanunchida.simpleloancalculator.data.SimpleAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val jsonFileString =
            getJsonDataFromAsset(applicationContext,"promotion.json")
        Log.i("data",jsonFileString!!)

//        val gson = Gson()
//        val listItemType = object :TypeToken<ArrayList<Simple>>(){}.type
//
//        var simpleList : ArrayList<Simple> = gson.fromJson(jsonFileString,listItemType)
//
//        //Log.i("data",monsterList[0].monsterName)
//
//        itemList = simpleList
//
//        val adapter = SimpleAdapter(this@MainActivity,DetailActivity2)
//
//        listView.adapter = adapter
//
//        listView.setOnItemClickListener { parent, view, position, id ->
//
//            var adapter = Intent(this@MainActivity,itemList::class.java)
//
//            intent.putExtra("title",itemList[position].promo_name)
//            intent.putExtra("caption",itemList[position].promo_code)
//            intent.putExtra("imageFile",itemList[position].imageFile)
//
//            startActivity(intent)

//        }
    }
}