package th.ac.su.chanunchida.simpleloancalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail2)
    }
}